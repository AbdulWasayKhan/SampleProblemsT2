#include <stdio.h>

/*Name: Abdul Wasay Khan, Student Number: 214981104*/

int main(int argc, char *argv[])
 {
    printf("{\"name\" : \"Abdul Wasay Khan\", \"student number\" : \"214981104\" : date \" November 28, 1994\"}\n");
    return 0;
 }
