#include <stdio.h>
#include <math.h>	

 double exponentiate(double x, int n) 
 {
  if(n == 0) {
	        return 1.0;
	    } else if(x == 0) {
		return 1.0;
		}
		else{
	        return x * exponentiate(x, n - 1);
	    }
	}

int main(int argc, char *argv[])
{
	printf("%f\n", exponentiate(5, 2));
	return 0;
}

