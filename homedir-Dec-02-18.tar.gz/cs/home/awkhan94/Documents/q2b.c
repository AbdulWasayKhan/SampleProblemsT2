#include <stdio.h>
#include <math.h>

/*computes the sum of m calls to term*/
double Series(double x, int n) 
{ 
    double sum = 1, term = 1, fct =1, p = 2, multi=1; 
  	
	int i; 
        for(i = 1; i < n; i++) { 
        fct = fct * multi * (multi+1); 
        p = p*x*x; 
        term = (-1) * term;         
        multi += 2; 
        sum = sum + (term * p)/fct; 
    } 
    return sum; 
} 

int main(int argc, char *argv[]) 
{ 
    double x = 9; 
    int n = 10; 
    printf("%.4f\n", Series(x, n)); 
    return 0; 
} 
