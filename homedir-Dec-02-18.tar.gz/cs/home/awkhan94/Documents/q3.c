# include <stdio.h>
# include <math.h>

/*Name: Abdul Wasay Khan, Student Number: 214981104*/

int solve(double a, double b, double c, double *root1, double *root2)
{

	   root1=(-b+sqrt(b*b-4*a*c))/(2*a);
	   root2=(-b-sqrt(b*b-4*a*c))/(2*a);
}
   tester(double a, double b, double c, char *msg)
 {
   tester(1.0, 0.0, 4.0, "no solution");
tester(1.0, 0.0, -4.0, "two solutions");
tester(1.0, 0.0, 0.0, "one solution");  
 }

   int main(int argc, char *argv[])
{
			
       printf(tester(1.0, 0.0, 4.0, "no solution"));
	printf(tester(1.0, 0.0, -4.0, "two solutions"));
	printf(tester(1.0, 0.0, 0.0, "one solution")); 
	return 0;
}
}
